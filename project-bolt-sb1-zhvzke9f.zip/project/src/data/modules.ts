import { Module } from '../types';

export const modules: Module[] = [
  {
    id: 1,
    title: "Pre-Checks Prior to Driving",
    description: "Essential vehicle inspection procedures before starting your journey",
    icon: "clipboard-check",
    content: `
      Pre-trip vehicle inspection is crucial for safe and efficient operation. This comprehensive guide covers all essential checks:

      1. External Inspection
      • Walk around the vehicle and check for any visible damage
      • Verify all lights are functioning (headlights, brake lights, turn signals)
      • Check tire condition, pressure, and tread depth
      • Inspect mirrors for proper positioning and damage
      • Check windshield and wipers for damage

      2. Under the Hood
      • Check engine oil level and condition
      • Verify coolant level and condition
      • Inspect power steering fluid
      • Check brake fluid level
      • Examine belts for wear and proper tension
      • Look for any fluid leaks

      3. Inside the Vehicle
      • Adjust seat and mirrors for optimal visibility
      • Test all dashboard warning lights
      • Check horn functionality
      • Verify seatbelt operation
      • Test parking brake
      • Check steering wheel play

      4. Documentation
      • Ensure all required documents are present and valid
      • Verify vehicle registration and insurance
      • Check service history records
      
      5. Safety Equipment
      • First aid kit completeness
      • Fire extinguisher presence and condition
      • Warning triangles/flares
      • Spare tire and jack presence

      Remember: A thorough pre-check can prevent breakdowns and accidents during your journey.
    `,
    questions: [
      {
        id: 1,
        text: "What should be the first step in a pre-trip inspection?",
        options: [
          "Start the engine",
          "Check under the hood",
          "Walk around the vehicle for visual inspection",
          "Check tire pressure"
        ],
        correctAnswer: 2
      },
      {
        id: 2,
        text: "How often should tire pressure be checked?",
        options: [
          "Once a month",
          "Before every trip",
          "Weekly",
          "Only when tires look low"
        ],
        correctAnswer: 1
      },
      {
        id: 3,
        text: "Which fluid should NOT be checked during a pre-trip inspection?",
        options: [
          "Engine oil",
          "Windshield washer fluid",
          "Brake fluid",
          "Air conditioning gas"
        ],
        correctAnswer: 3
      },
      {
        id: 4,
        text: "What is the minimum legal tread depth for commercial vehicle tires?",
        options: [
          "1/32 inch",
          "2/32 inch",
          "4/32 inch",
          "6/32 inch"
        ],
        correctAnswer: 2
      },
      {
        id: 5,
        text: "Which document is NOT typically required during a pre-trip inspection?",
        options: [
          "Driver's license",
          "Vehicle registration",
          "Insurance certificate",
          "Vehicle purchase invoice"
        ],
        correctAnswer: 3
      },
      {
        id: 6,
        text: "What should you check about the windshield wipers?",
        options: [
          "Only the wiper fluid level",
          "Only the wiper blade condition",
          "Both fluid level and blade condition",
          "Neither - wipers are not part of pre-trip inspection"
        ],
        correctAnswer: 2
      },
      {
        id: 7,
        text: "How much free play is typically acceptable in steering wheel?",
        options: [
          "No free play",
          "1-2 inches",
          "3-4 inches",
          "5-6 inches"
        ],
        correctAnswer: 1
      },
      {
        id: 8,
        text: "What should you do if you find a major defect during inspection?",
        options: [
          "Note it down and start the journey",
          "Ignore if vehicle seems driveable",
          "Report and do not drive until fixed",
          "Fix it yourself immediately"
        ],
        correctAnswer: 2
      },
      {
        id: 9,
        text: "Which safety equipment is NOT typically required?",
        options: [
          "First aid kit",
          "Fire extinguisher",
          "Warning triangles",
          "Spare engine oil"
        ],
        correctAnswer: 3
      },
      {
        id: 10,
        text: "When checking mirrors, what should you verify?",
        options: [
          "Only cleanliness",
          "Only proper adjustment",
          "Both cleanliness and adjustment",
          "Neither - mirrors don't need checking"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 2,
    title: "Safety During Fueling",
    description: "Essential safety protocols during vehicle fueling",
    icon: "fuel",
    content: `
      Proper fueling procedures are crucial for safety. This module covers all essential aspects:

      1. Before Fueling
      • Turn off engine
      • Engage parking brake
      • No smoking or open flames
      • Check for correct fuel type
      • Ground yourself to prevent static electricity
      
      2. During Fueling
      • Stay near the fuel nozzle
      • Don't overfill
      • Avoid fuel spillage
      • Watch for hazards
      • No use of mobile phones
      
      3. Emergency Procedures
      • Location of emergency shut-off
      • Spill response protocols
      • Fire safety measures
      • Emergency contact numbers
      
      4. Environmental Considerations
      • Proper handling of fuel spills
      • Environmental impact awareness
      • Waste disposal procedures
      
      5. Documentation
      • Fuel receipt procedures
      • Mileage recording
      • Fuel consumption monitoring
      
      Remember: Safety during fueling is not just about preventing fires - it's about protecting yourself, others, and the environment.
    `,
    questions: [
      {
        id: 1,
        text: "What should you do first before fueling?",
        options: [
          "Check fuel prices",
          "Turn off engine",
          "Clean windshield",
          "Check tire pressure"
        ],
        correctAnswer: 1
      },
      {
        id: 2,
        text: "Why is using a mobile phone during fueling dangerous?",
        options: [
          "It's distracting",
          "It can cause static electricity",
          "It interferes with the fuel pump",
          "It affects fuel quality"
        ],
        correctAnswer: 1
      },
      {
        id: 3,
        text: "What should you do if fuel spills during filling?",
        options: [
          "Ignore small spills",
          "Wash it away with water",
          "Notify station staff immediately",
          "Cover it with sand"
        ],
        correctAnswer: 2
      },
      {
        id: 4,
        text: "How far should you fill the fuel tank?",
        options: [
          "Until it automatically stops",
          "Until you see fuel in the neck",
          "Past the automatic stop",
          "Half tank only"
        ],
        correctAnswer: 0
      },
      {
        id: 5,
        text: "What should you check before starting to fuel?",
        options: [
          "Only fuel price",
          "Only fuel type",
          "Both price and type",
          "Neither - just start fueling"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "Where should the fuel cap be placed during fueling?",
        options: [
          "On the ground",
          "In your pocket",
          "In the fuel cap holder",
          "Anywhere convenient"
        ],
        correctAnswer: 2
      },
      {
        id: 7,
        text: "What should you do if there's a fire during fueling?",
        options: [
          "Use water to extinguish",
          "Remove the nozzle",
          "Hit emergency shut-off and evacuate",
          "Continue fueling quickly"
        ],
        correctAnswer: 2
      },
      {
        id: 8,
        text: "How often should you check fuel levels?",
        options: [
          "Only when low",
          "Daily before starting",
          "Weekly",
          "Monthly"
        ],
        correctAnswer: 1
      },
      {
        id: 9,
        text: "What documentation is required after fueling?",
        options: [
          "Just the receipt",
          "Receipt and mileage record",
          "No documentation needed",
          "Only mileage record"
        ],
        correctAnswer: 1
      },
      {
        id: 10,
        text: "When is it safe to restart the engine after fueling?",
        options: [
          "Immediately",
          "After 30 seconds",
          "After replacing cap and nozzle",
          "After paying"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 3,
    title: "Basic Vehicle Defects & Repairs",
    description: "Identifying and addressing common vehicle issues",
    icon: "wrench",
    content: `
      Understanding basic vehicle defects and emergency repairs is essential for every driver:

      1. Common Engine Issues
      • Warning light interpretation
      • Unusual sounds and vibrations
      • Smoke color meaning
      • Engine temperature issues
      • Starting problems
      
      2. Electrical System
      • Battery problems
      • Alternator issues
      • Starter motor failures
      • Fuse replacement
      • Light system troubles
      
      3. Brake System
      • Brake noise identification
      • Pedal feel interpretation
      • Brake fluid leaks
      • Emergency brake issues
      • ABS system warnings
      
      4. Tire Problems
      • Puncture identification
      • Wear patterns
      • Emergency tire change
      • Pressure monitoring
      • Alignment issues
      
      5. Emergency Repairs
      • Safe breakdown procedures
      • Basic tool usage
      • When to call for help
      • Temporary fix guidelines
      • Safety during repairs

      Remember: Safety first - if in doubt, contact professional help.
    `,
    questions: [
      {
        id: 1,
        text: "What does blue smoke from the exhaust indicate?",
        options: [
          "Water in fuel",
          "Oil burning",
          "Fuel mixture too rich",
          "Normal operation"
        ],
        correctAnswer: 1
      },
      {
        id: 2,
        text: "When should you check the battery terminals?",
        options: [
          "Only when battery dies",
          "Monthly",
          "Yearly",
          "Never - it's a mechanic's job"
        ],
        correctAnswer: 1
      },
      {
        id: 3,
        text: "What causes squealing brakes?",
        options: [
          "Normal operation",
          "Worn brake pads",
          "Too much brake fluid",
          "ABS activation"
        ],
        correctAnswer: 1
      },
      {
        id: 4,
        text: "How do you check tire tread depth?",
        options: [
          "Visual inspection only",
          "Use a tread depth gauge",
          "Drive feel",
          "Wait for warning light"
        ],
        correctAnswer: 1
      },
      {
        id: 5,
        text: "What should you do if the engine overheats?",
        options: [
          "Keep driving slowly",
          "Add cold water immediately",
          "Stop and let it cool",
          "Increase speed to cool engine"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "When should you replace windshield wipers?",
        options: [
          "When they streak",
          "Every 6 months",
          "When they break",
          "Yearly"
        ],
        correctAnswer: 0
      },
      {
        id: 7,
        text: "What indicates a bad alternator?",
        options: [
          "Engine won't start",
          "Dim lights while running",
          "Brake squealing",
          "Oil pressure low"
        ],
        correctAnswer: 1
      },
      {
        id: 8,
        text: "How often should brake fluid be checked?",
        options: [
          "Monthly",
          "Weekly",
          "Daily",
          "Only when brakes feel soft"
        ],
        correctAnswer: 0
      },
      {
        id: 9,
        text: "What tool is needed to change a tire?",
        options: [
          "Only jack",
          "Only lug wrench",
          "Both jack and lug wrench",
          "Neither"
        ],
        correctAnswer: 2
      },
      {
        id: 10,
        text: "When should you not attempt a repair?",
        options: [
          "In rain",
          "At night",
          "When tools available",
          "When safety is compromised"
        ],
        correctAnswer: 3
      }
    ]
  },
  {
    id: 4,
    title: "Advanced Vehicle Operations",
    description: "Operating modern vehicles with advanced features",
    icon: "cpu",
    content: `
      Modern vehicles require understanding of advanced features and systems:

      1. Advanced Sensor Systems
      • Proximity sensors
      • Parking assistance
      • Blind spot monitoring
      • Lane departure warning
      • Adaptive cruise control
      
      2. Hybrid Vehicle Operation
      • Battery management
      • Regenerative braking
      • Power mode selection
      • Energy efficiency
      • Charging procedures
      
      3. Modern Safety Features
      • Emergency brake assist
      • Stability control
      • Traction control
      • Airbag systems
      • Collision avoidance
      
      4. Vehicle Electronics
      • Infotainment systems
      • Navigation systems
      • Climate control
      • Drive mode selection
      • Vehicle diagnostics
      
      5. Maintenance Considerations
      • Special fluid requirements
      • Battery care
      • Sensor calibration
      • Software updates
      • Service intervals

      Remember: Modern vehicles require different handling and maintenance approaches than traditional vehicles.
    `,
    questions: [
      {
        id: 1,
        text: "What is the purpose of regenerative braking?",
        options: [
          "Faster stopping",
          "Battery charging",
          "Brake pad preservation",
          "Improved handling"
        ],
        correctAnswer: 1
      },
      {
        id: 2,
        text: "When should lane departure warning be disabled?",
        options: [
          "Never",
          "In heavy traffic",
          "During road work",
          "At night"
        ],
        correctAnswer: 2
      },
      {
        id: 3,
        text: "How often should hybrid batteries be charged?",
        options: [
          "Daily",
          "When fully depleted",
          "At 20% charge",
          "Weekly"
        ],
        correctAnswer: 2
      },
      {
        id: 4,
        text: "What affects adaptive cruise control performance?",
        options: [
          "Radio usage",
          "Weather conditions",
          "Tire pressure",
          "Fuel level"
        ],
        correctAnswer: 1
      },
      {
        id: 5,
        text: "How often should sensor calibration be checked?",
        options: [
          "Never",
          "After accidents only",
          "According to manual",
          "Monthly"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "What is the purpose of drive mode selection?",
        options: [
          "Better fuel economy",
          "Enhanced performance",
          "Both A and B",
          "Neither"
        ],
        correctAnswer: 2
      },
      {
        id: 7,
        text: "When should stability control be turned off?",
        options: [
          "Never",
          "In snow",
          "At high speeds",
          "In rain"
        ],
        correctAnswer: 0
      },
      {
        id: 8,
        text: "How often should software updates be checked?",
        options: [
          "Monthly",
          "During service only",
          "When notified",
          "Never"
        ],
        correctAnswer: 2
      },
      {
        id: 9,
        text: "What affects blind spot monitoring?",
        options: [
          "Vehicle color",
          "Weather conditions",
          "Radio usage",
          "Fuel type"
        ],
        correctAnswer: 1
      },
      {
        id: 10,
        text: "When using parking assistance, what should you still do?",
        options: [
          "Close your eyes",
          "Accelerate quickly",
          "Check surroundings manually",
          "Turn off other systems"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 5,
    title: "Road Safety & Traffic Rules",
    description: "Understanding and following traffic regulations",
    icon: "alert-triangle",
    content: `
      Road safety and traffic rules are fundamental for safe driving:

      1. Basic Traffic Rules
      • Right of way
      • Speed limits
      • Lane discipline
      • Traffic signals
      • Road signs
      
      2. Safety Distances
      • Following distance
      • Stopping distance
      • Emergency stopping
      • Space management
      • Weather adjustments
      
      3. Intersection Safety
      • Right of way rules
      • Turn procedures
      • Pedestrian rights
      • Signal interpretation
      • Roundabout rules
      
      4. Special Conditions
      • Night driving
      • Adverse weather
      • Construction zones
      • Emergency vehicles
      • School zones
      
      5. Defensive Driving
      • Hazard awareness
      • Anticipation
      • Risk assessment
      • Emergency maneuvers
      • Accident prevention

      Remember: Traffic rules exist to protect all road users - following them saves lives.
    `,
    questions: [
      {
        id: 1,
        text: "What is the safe following distance in good conditions?",
        options: [
          "1 second",
          "2 seconds",
          "3 seconds",
          "4 seconds"
        ],
        correctAnswer: 2
      },
      {
        id: 2,
        text: "When should you reduce speed?",
        options: [
          "In rain only",
          "At night only",
          "In all adverse conditions",
          "When police present"
        ],
        correctAnswer: 2
      },
      {
        id: 3,
        text: "Who has right of way at an unmarked intersection?",
        options: [
          "Larger vehicle",
          "Vehicle on right",
          "Faster vehicle",
          "First to arrive"
        ],
        correctAnswer: 1
      },
      {
        id: 4,
        text: "What should you do when emergency vehicles approach?",
        options: [
          "Speed up",
          "Stop immediately",
          "Pull over safely",
          "Ignore them"
        ],
        correctAnswer: 2
      },
      {
        id: 5,
        text: "When is passing on the right allowed?",
        options: [
          "Never",
          "When left lane is blocked",
          "During rush hour",
          "When in hurry"
        ],
        correctAnswer: 1
      },
      {
        id: 6,
        text: "What is the speed limit in a school zone?",
        options: [
          "15 mph",
          "20 mph",
          "25 mph",
          "30 mph"
        ],
        correctAnswer: 1
      },
      {
        id: 7,
        text: "When should high beams be used?",
        options: [
          "Always at night",
          "Never",
          "When no oncoming traffic",
          "In rain"
        ],
        correctAnswer: 2
      },
      {
        id: 8,
        text: "What is defensive driving?",
        options: [
          "Driving slowly",
          "Anticipating hazards",
          "Following closely",
          "Ignoring others"
        ],
        correctAnswer: 1
      },
      {
        id: 9,
        text: "When should you signal a turn?",
        options: [
          "During turn",
          "Just before turn",
          "100 feet before",
          "After turning"
        ],
        correctAnswer: 2
      },
      {
        id: 10,
        text: "What should you do at a yellow light?",
        options: [
          "Speed up",
          "Stop if safe",
          "Always stop",
          "Ignore it"
        ],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 6,
    title: "Safe Driving Practices",
    description: "Essential techniques for safe vehicle operation",
    icon: "shield",
    content: `
      Safe driving practices are essential for accident prevention:

      1. Proper Positioning
      • Seat adjustment
      • Mirror positioning
      • Steering technique
      • Foot placement
      • Head position
      
      2. Visual Habits
      • Scanning patterns
      • Mirror checks
      • Blind spot awareness
      • Forward planning
      • Hazard detection
      
      3. Speed Management
      • Speed selection
      • Distance control
      • Acceleration technique
      • Deceleration method
      • Emergency stopping
      
      4. Weather Adaptation
      • Rain driving
      • Snow handling
      • Fog navigation
      • Wind compensation
      • Temperature effects
      
      5. Special Maneuvers
      • Parking techniques
      • Reversing safety
      • Turn execution
      • Lane changing
      • Merging procedures

      Remember: Safe driving is about developing good habits and maintaining them consistently.
    `,
    questions: [
      {
        id: 1,
        text: "How often should you check mirrors?",
        options: [
          "Every 5-8 seconds",
          "Every minute",
          "When changing lanes",
          "When stopping"
        ],
        correctAnswer: 0
      },
      {
        id: 2,
        text: "What is the correct steering wheel position?",
        options: [
          "12 and 6",
          "10 and 2",
          "9 and 3",
          "8 and 4"
        ],
        correctAnswer: 2
      },
      {
        id: 3,
        text: "When should you check blind spots?",
        options: [
          "Every 30 seconds",
          "Before lane changes",
          "At stops only",
          "Never"
        ],
        correctAnswer: 1
      },
      {
        id: 4,
        text: "What is the proper following distance in rain?",
        options: [
          "2 seconds",
          "3 seconds",
          "4 seconds",
          "6 seconds"
        ],
        correctAnswer: 3
      },
      {
        id: 5,
        text: "How should you hold the steering wheel?",
        options: [
          "One hand",
          "Palms only",
          "Firm grip",
          "Loose grip"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "When merging, what should you check first?",
        options: [
          "Speed only",
          "Mirrors only",
          "Speed and mirrors",
          "Nothing"
        ],
        correctAnswer: 2
      },
      {
        id: 7,
        text: "What is the safest reversing technique?",
        options: [
          "Use mirrors only",
          "Look back only",
          "Use all available views",
          "Reverse quickly"
        ],
        correctAnswer: 2
      },
      {
        id: 8,
        text: "How should you adjust side mirrors?",
        options: [
          "See your car",
          "Eliminate blind spots",
          "Point downward",
          "Maximum overlap"
        ],
        correctAnswer: 1
      },
      {
        id: 9,
        text: "What is proper foot positioning?",
        options: [
          "Heel on floor",
          "Whole foot on pedal",
          "Toes only",
          "Doesn't matter"
        ],
        correctAnswer: 0
      },
      {
        id: 10,
        text: "When should you scan intersections?",
        options: [
          "After entering",
          "While stopping",
          "Before and during",
          "Never"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 7,
    title: "First Aid & Life Saving",
    description: "Essential medical emergency response procedures",
    icon: "heart-pulse",
    content: `
      First aid knowledge can save lives in emergency situations:

      1. Basic Life Support
      • CPR techniques
      • Recovery position
      • Choking response
      • Breathing assessment
      • Pulse checking
      
      2. Injury Management
      • Bleeding control
      • Fracture handling
      • Burn treatment
      • Sprain care
      • Head injury protocol
      
      3. Medical Emergencies
      • Heart attack signs
      • Stroke recognition
      • Diabetic emergencies
      • Seizure management
      • Allergic reactions
      
      4. Environmental Emergencies
      • Heat exhaustion
      • Hypothermia
      • Dehydration
      • Sunstroke
      • Frostbite
      
      5. Emergency Response
      • Calling for help
      • Scene assessment
      • Victim approach
      • Documentation
      • Handover procedures

      Remember: Quick and correct first aid action can mean the difference between life and death.
    `,
    questions: [
      {
        id: 1,
        text: "What is the first step in any emergency?",
        options: [
          "Start CPR",
          "Call for help",
          "Check scene safety",
          "Check pulse"
        ],
        correctAnswer: 2
      },
      {
        id: 2,
        text: "What is the correct CPR compression rate?",
        options: [
          "60-80 per minute",
          "100-120 per minute",
          "140-160 per minute",
          "180-200 per minute"
        ],
        correctAnswer: 1
      },
      {
        id: 3,
        text: "How do you treat severe bleeding?",
        options: [
          "Apply direct pressure",
          "Elevate wound",
          "Apply tourniquet",
          "Clean with water"
        ],
        correctAnswer: 0
      },
      {
        id: 4,
        text: "What are signs of heat exhaustion?",
        options: [
          "Shivering",
          "Heavy sweating",
          "Dry skin",
          "High energy"
        ],
        correctAnswer: 1
      },
      {
        id: 5,
        text: "How do you treat a burn?",
        options: [
          "Apply ice",
          "Apply butter",
          "Cool running water",
          "Apply cream"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "What is the recovery position used for?",
        options: [
          "Unconscious breathing",
          "Chest pain",
          "Broken bones",
          "Bleeding"
        ],
        correctAnswer: 0
      },
      {
        id: 7,
        text: "How do you recognize a stroke?",
        options: [
          "FAST method",
          "Check pulse",
          "Test reflexes",
          "Check breathing"
        ],
        correctAnswer: 0
      },
      {
        id: 8,
        text: "What should you do for a seizure?",
        options: [
          "Restrain person",
          "Put something in mouth",
          "Protect from injury",
          "Start CPR"
        ],
        correctAnswer: 2
      },
      {
        id: 9,
        text: "How long should you check for breathing?",
        options: [
          "5 seconds",
          "10 seconds",
          "15 seconds",
          "20 seconds"
        ],
        correctAnswer: 1
      },
      {
        id: 10,
        text: "What is the first step for choking?",
        options: [
          "Back blows",
          "Heimlich maneuver",
          "Encourage coughing",
          "Call ambulance"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 8,
    title: "Effects of Alcohol on Driving",
    description: "Understanding the dangers of drunk driving",
    icon: "alert-octagon",
    content: `
      Understanding alcohol's effects on driving is crucial for safety:

      1. Physical Effects
      • Vision impairment
      • Reaction time
      • Coordination loss
      • Balance disruption
      • Judgment impairment
      
      2. Legal Consequences
      • Blood alcohol limits
      • Testing procedures
      • Legal penalties
      • License suspension
      • Criminal record
      
      3. Social Impact
      • Family effects
      • Career impact
      • Social stigma
      • Insurance costs
      • Financial burden
      
      4. Prevention Strategies
      • Alternative transport
      • Designated driver
      • Planning ahead
      • Alcohol awareness
      • Peer pressure
      
      5. Recovery Programs
      • Support services
      • Rehabilitation
      • Counseling options
      • Prevention programs
      • Education resources

      Remember: There is never a safe amount of alcohol when driving.
    `,
    questions: [
      {
        id: 1,
        text: "What is the legal blood alcohol limit for commercial drivers?",
        options: [
          "0.08%",
          "0.04%",
          "0.02%",
          "0.00%"
        ],
        correctAnswer: 1
      },
      {
        id: 2,
        text: "How does alcohol affect reaction time?",
        options: [
          "Improves it",
          "No effect",
          "Slows it down",
          "Varies by person"
        ],
        correctAnswer: 2
      },
      {
        id: 3,
        text: "When is it safe to drive after drinking?",
        options: [
          "After coffee",
          "After sleeping",
          "After eating",
          "When completely sober"
        ],
        correctAnswer: 3
      },
      {
        id: 4,
        text: "What is the first thing affected by alcohol?",
        options: [
          "Vision",
          "Judgment",
          "Coordination",
          "Speech"
        ],
        correctAnswer: 1
      },
      {
        id: 5,
        text: "How long does alcohol stay in your system?",
        options: [
          "1 hour per drink",
          "2 hours per drink",
          "Varies by person",
          "Fixed 4 hours"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "What can reduce blood alcohol content?",
        options: [
          "Coffee",
          "Exercise",
          "Food",
          "Only time"
        ],
        correctAnswer: 3
      },
      {
        id: 7,
        text: "What is the minimum license suspension for DUI?",
        options: [
          "30 days",
          "60 days",
          "90 days",
          "180 days"
        ],
        correctAnswer: 2
      },
      {
        id: 8,
        text: "How does alcohol affect depth perception?",
        options: [
          "Improves it",
          "No effect",
          "Impairs it",
          "Varies by amount"
        ],
        correctAnswer: 2
      },
      {
        id: 9,
        text: "What is the best prevention for drunk driving?",
        options: [
          "Coffee",
          "Food",
          
          "Planning ahead",
          "Walking"
        ],
        correctAnswer: 2
      },
      {
        id: 10,
        text: "Who can be held liable in a drunk driving accident?",
        options: [
          "Only driver",
          "Only owner",
          "Multiple parties",
          "No one"
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 9,
    title: "Vehicle Parade Procedures",
    description: "Guidelines for organizing and participating in vehicle parades",
    icon: "flag",
    content: `
      Vehicle parade procedures require specific knowledge and skills:

      1. Preparation
      • Vehicle inspection
      • Formation planning
      • Communication setup
      • Route familiarization
      • Equipment check
      
      2. Formation Rules
      • Spacing guidelines
      • Speed control
      • Lane positioning
      • Signal protocols
      • Emergency procedures
      
      3. Communication
      • Hand signals
      • Radio protocols
      • Emergency signals
      • Formation changes
      • Stop/start procedures
      
      4. Safety Measures
      • Distance maintenance
      • Speed control
      • Hazard awareness
      • Emergency procedures
      • Public safety
      
      5. Special Considerations
      • Weather effects
      • Route obstacles
      • Public interaction
      • Time management
      • Contingency plans

      Remember: Parade formation requires perfect coordination and communication.
    `,
    questions: [
      {
        id: 1,
        text: "What is the standard vehicle spacing in parade formation?",
        options: [
          "One car length",
          "Two car lengths",
          "Three car lengths",
          "Four car lengths"
        ],
        correctAnswer: 1
      },
      {
        id: 2,
        text: "When should parade formation be broken?",
        options: [
          "Never",
          "In emergency only",
          "At leader's signal",
          "When convenient"
        ],
        correctAnswer: 1
      },
      {
        id: 3,
        text: "What is the primary method of parade communication?",
        options: [
          "Horn signals",
          "Hand signals",
          "Radio",
          "Flashing lights"
        ],
        correctAnswer: 2
      },
      {
        id: 4,
        text: "How should speed be maintained in formation?",
        options: [
          "Watch speedometer",
          "Follow leader exactly",
          "Maintain fixed spacing",
          "Use cruise control"
        ],
        correctAnswer: 2
      },
      {
        id: 5,
        text: "What should be checked before parade formation?",
        options: [
          "Fuel only",
          "Radio only",
          "All systems",
          "Nothing special"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "How should lane changes be executed?",
        options: [
          "Individually",
          "As directed",
          "When convenient",
          "Never"
        ],
        correctAnswer: 1
      },
      {
        id: 7,
        text: "What is the correct response to formation gaps?",
        options: [
          "Speed up quickly",
          "Gradually close gap",
          "Maintain gap",
          "Signal others"
        ],
        correctAnswer: 1
      },
      {
        id: 8,
        text: "When should headlights be used?",
        options: [
          "Never",
          "Always",
          "As directed",
          "At night only"
        ],
        correctAnswer: 2
      },
      {
        id: 9,
        text: "How should emergency vehicles be handled?",
        options: [
          "Ignore them",
          "Break formation",
          "Follow procedure",
          "Speed up"
        ],
        correctAnswer: 2
      },
      {
        id: 10,
        text: "What is the minimum following distance in rain?",
        options: [
          "Same as dry",
          "Double normal",
          "Triple normal",
          "Leader's choice"
        ],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 10,
    title: "Vehicle Documentation",
    description: "Proper maintenance of vehicle records and documentation",
    icon: "file-text",
    content: `
      Proper vehicle documentation is crucial for fleet management:

      1. Required Documents
      • Registration papers
      • Insurance certificates
      • Maintenance records
      • Inspection reports
      • Driver logs
      
      2. Log Book Entries
      • Mileage recording
      • Fuel consumption
      • Maintenance notes
      • Incident reports
      • Driver changes
      
      3. Maintenance Records
      • Service schedules
      • Repair history
      • Part replacements
      • Oil changes
      • Tire rotations
      
      4. Incident Documentation
      • Accident reports
      • Damage assessment
      • Repair estimates
      • Insurance claims
      • Follow-up actions
      
      5. Electronic Records
      • Digital logging
      • Backup procedures
      • Data security
      • Access control
      • Update protocols

      Remember: Accurate documentation protects both driver and organization.
    `,
    questions: [
      {
        id: 1,
        text: "How often should mileage be recorded?",
        options: [
          "Weekly",
          "Monthly",
          "Each trip",
          "Daily"
        ],
        correctAnswer: 2
      },
      {
        id: 2,
        text: "What must be recorded after fueling?",
        options: [
          "Only amount",
          "Only mileage",
          "Both amount and mileage",
          "Neither"
        ],
        correctAnswer: 2
      },
      {
        id: 3,
        text: "When should maintenance be logged?",
        options: [
          "Monthly",
          "After completion",
          "Before service",
          "Annually"
        ],
        correctAnswer: 1
      },
      {
        id: 4,
        text: "How long should records be kept?",
        options: [
          "1 year",
          "2 years",
          "3 years",
          "5 years"
        ],
        correctAnswer: 3
      },
      {
        id: 5,
        text: "What should be recorded after an incident?",
        options: [
          "Date only",
          "Damage only",
          "All details",
          "Nothing"
        ],
        correctAnswer: 2
      },
      {
        id: 6,
        text: "How should corrections be made in logbooks?",
        options: [
          "Erase error",
          "Cross out and initial",
          "White out",
          "New entry"
        ],
        correctAnswer: 1
      },
      {
        id: 7,
        text: "When should vehicle inspection be documented?",
        options: [
          "Monthly",
          "Weekly",
          "Daily",
          "Before trips"
        ],
        correctAnswer: 2
      },
      {
        id: 8,
        text: "What format should dates use?",
        options: [
          "MM/DD/YY",
          "DD/MM/YY",
          "YY/MM/DD",
          "Standard format"
        ],
        correctAnswer: 3
      },
      {
        id: 9,
        text: "Who should sign maintenance records?",
        options: [
          "Driver only",
          "Mechanic only",
          "Both parties",
          "Supervisor only"
        ],
        correctAnswer: 2
      },
      {
        id: 10,
        text: "How often should backup copies be made?",
        options: [
          "Never",
          "Monthly",
          "Weekly",
          "Daily"
        ],
        correctAnswer: 3
      }
    ]
  }
];