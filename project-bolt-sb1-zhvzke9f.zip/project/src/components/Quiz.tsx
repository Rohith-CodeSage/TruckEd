import React, { useState } from 'react';
import { Question } from '../types';

interface QuizProps {
  questions: Question[];
  onComplete: (score: number) => void;
}

export function Quiz({ questions, onComplete }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<{correct: number[], incorrect: number[]}>({
    correct: [],
    incorrect: []
  });

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...answers, optionIndex];
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      // Calculate results
      const correct: number[] = [];
      const incorrect: number[] = [];
      newAnswers.forEach((answer, index) => {
        if (answer === questions[index].correctAnswer) {
          correct.push(index);
        } else {
          incorrect.push(index);
        }
      });
      setResults({ correct, incorrect });
      setShowResults(true);
    }
  };

  const handleFinish = () => {
    const score = (results.correct.length / questions.length) * 100;
    onComplete(score);
  };

  if (showResults) {
    return (
      <div className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-lg">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Quiz Results</h3>
        <div className="mb-6">
          <p className="text-lg mb-2">
            Correct Answers: <span className="font-bold text-green-600">{results.correct.length}</span>
          </p>
          <p className="text-lg mb-4">
            Incorrect Answers: <span className="font-bold text-red-600">{results.incorrect.length}</span>
          </p>
          <div className="w-full h-2 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-green-600 rounded-full transition-all duration-300"
              style={{ width: `${(results.correct.length / questions.length) * 100}%` }}
            />
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-xl font-semibold text-gray-800">Review:</h4>
          {questions.map((question, index) => (
            <div 
              key={index}
              className={`p-4 rounded-lg ${
                results.correct.includes(index) ? 'bg-green-50' : 'bg-red-50'
              }`}
            >
              <p className="font-medium mb-2">{question.text}</p>
              <p className="text-sm">
                Your answer: <span className={results.correct.includes(index) ? 'text-green-600' : 'text-red-600'}>
                  {question.options[answers[index]]}
                </span>
              </p>
              {!results.correct.includes(index) && (
                <p className="text-sm mt-1">
                  Correct answer: <span className="text-green-600">
                    {question.options[question.correctAnswer]}
                  </span>
                </p>
              )}
            </div>
          ))}
        </div>

        <button
          onClick={handleFinish}
          className="mt-6 w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors duration-300"
        >
          Complete Review
        </button>
      </div>
    );
  }

  const question = questions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-gray-800">Question {currentQuestion + 1} of {questions.length}</h3>
          <div className="text-sm text-gray-500">
            Progress: {Math.round((currentQuestion / questions.length) * 100)}%
          </div>
        </div>
        <div className="w-full h-2 bg-gray-200 rounded-full">
          <div 
            className="h-full bg-blue-600 rounded-full transition-all duration-300"
            style={{ width: `${(currentQuestion / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <h4 className="text-lg font-medium text-gray-800 mb-6">{question.text}</h4>

      <div className="space-y-4">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleAnswer(index)}
            className="w-full p-4 text-left bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors duration-300"
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}