import React from 'react';
import { BookOpen, Code2, Database, FileText, Gauge, GitBranch, Globe, Layout, Lock, Server, Settings, Shield, Terminal, Type, Users, DivideIcon as LucideIcon } from 'lucide-react';
import { Module } from '../types';

// Map of icon names to their components
const iconMap: Record<string, LucideIcon> = {
  'book-open': BookOpen,
  'code2': Code2,
  'database': Database,
  'file-text': FileText,
  'gauge': Gauge,
  'git-branch': GitBranch,
  'globe': Globe,
  'layout': Layout,
  'lock': Lock,
  'server': Server,
  'settings': Settings,
  'shield': Shield,
  'terminal': Terminal,
  'type': Type,
  'users': Users
};

interface ModuleCardProps {
  module: Module;
  progress: number;
  onClick: () => void;
}

export function ModuleCard({ module, progress, onClick }: ModuleCardProps) {
  const IconComponent = iconMap[module.icon] || FileText; // Fallback to FileText if icon not found

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-xl shadow-lg p-6 cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-xl"
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="p-3 bg-blue-100 rounded-lg">
          <IconComponent className="w-6 h-6 text-blue-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-800">{module.title}</h3>
      </div>
      <p className="text-gray-600 mb-4">{module.description}</p>
      <div className="relative w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="absolute top-0 left-0 h-full bg-blue-600 transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
      <p className="text-sm text-gray-500 mt-2">{progress}% complete</p>
    </div>
  );
}