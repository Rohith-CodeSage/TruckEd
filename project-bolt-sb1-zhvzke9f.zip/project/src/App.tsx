import React, { useState } from 'react';
import { Truck, GraduationCap } from 'lucide-react';
import { modules } from './data/modules';
import { ModuleCard } from './components/ModuleCard';
import { Quiz } from './components/Quiz';
import { Module, UserProgress } from './types';

function App() {
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [progress, setProgress] = useState<UserProgress[]>([]);

  const handleModuleSelect = (module: Module) => {
    setSelectedModule(module);
    setShowQuiz(false);
  };

  const handleStartQuiz = () => {
    setShowQuiz(true);
  };

  const handleQuizComplete = (score: number) => {
    if (selectedModule) {
      setProgress(prev => [
        ...prev.filter(p => p.moduleId !== selectedModule.id),
        { moduleId: selectedModule.id, completed: true, score }
      ]);
      setShowQuiz(false);
      setSelectedModule(null);
    }
  };

  const getModuleProgress = (moduleId: number) => {
    const moduleProgress = progress.find(p => p.moduleId === moduleId);
    return moduleProgress ? moduleProgress.score : 0;
  };

  if (showQuiz && selectedModule) {
    return (
      <div className="min-h-screen bg-gray-100 py-12 px-4">
        <Quiz 
          questions={selectedModule.questions}
          onComplete={handleQuizComplete}
        />
      </div>
    );
  }

  if (selectedModule) {
    return (
      <div className="min-h-screen bg-gray-100 py-12 px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
          <button
            onClick={() => setSelectedModule(null)}
            className="mb-6 text-blue-600 hover:text-blue-800 flex items-center gap-2"
          >
            ← Back to Modules
          </button>
          <h2 className="text-3xl font-bold text-gray-800 mb-6">{selectedModule.title}</h2>
          <div className="prose max-w-none mb-8">
            {selectedModule.content.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4">{paragraph}</p>
            ))}
          </div>
          <button
            onClick={handleStartQuiz}
            className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors duration-300"
          >
            Start Quiz
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-12">
          <div className="p-3 bg-blue-600 rounded-lg">
            <Truck className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-gray-800">TruckEd</h1>
            <p className="text-gray-600">Your Journey to Professional Truck Driving</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 mb-12">
          <div className="flex items-center gap-4 mb-6">
            <GraduationCap className="w-6 h-6 text-blue-600" />
            <h2 className="text-2xl font-semibold text-gray-800">Learning Modules</h2>
          </div>
          <p className="text-gray-600">
            Complete all modules to become a certified professional truck driver. Each module includes
            comprehensive content and a quiz to test your knowledge.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {modules.map(module => (
            <ModuleCard
              key={module.id}
              module={module}
              progress={getModuleProgress(module.id)}
              onClick={() => handleModuleSelect(module)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;