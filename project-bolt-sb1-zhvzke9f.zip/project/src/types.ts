export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Module {
  id: number;
  title: string;
  description: string;
  icon: string;
  content: string;
  questions: Question[];
}

export interface UserProgress {
  moduleId: number;
  completed: boolean;
  score: number;
}